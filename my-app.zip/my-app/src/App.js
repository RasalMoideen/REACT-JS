
import './assets/css/style.css'
import './assets/css/global.css'
import {useState} from "react"

function App() {

  const [count, setCount] = useState(0);

  function myFunction() {
    return (
      setCount(count + 1)   
    )
  }

  // arrow function   
  // const myFunction = () => setCount(count + 5);

  return (
    
    <div className = 'head' >
      <button className = 'btn-csm bg-primary-csm' onClick = { myFunction } > + Add </button>
      <h2 className = 'card' > Counter : {count} </h2>
    </div>

  );
}

export default App;
